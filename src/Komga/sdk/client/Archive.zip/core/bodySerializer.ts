/* eslint-disable @typescript-eslint/no-explicit-any */
import type {
  ArrayStyle,
  ObjectStyle,
  SerializerOptions,
} from './pathSerializer.js';

export type QuerySerializer = (query: Record<string, unknown>) => string;

export type BodySerializer = (body: any) => any;

export interface QuerySerializerOptions {
  allowReserved?: boolean;
  array?: SerializerOptions<ArrayStyle>;
  object?: SerializerOptions<ObjectStyle>;
}

export const formDataBodySerializer = {
  bodySerializer: <T extends Record<string, any> | Array<Record<string, any>>>(
    body: T,
  ) => {
    return body
  },
};

export const jsonBodySerializer = {
  bodySerializer: <T>(body: T) =>
    JSON.stringify(body, (key, value) =>
      typeof value === 'bigint' ? value.toString() : value,
    ),
};

export const urlSearchParamsBodySerializer = {
  bodySerializer: <T extends Record<string, any> | Array<Record<string, any>>>(
    body: T,
  ) => {
    return body
  },
};
