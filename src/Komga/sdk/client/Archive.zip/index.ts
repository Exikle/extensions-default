export { createClient } from './client.js';
export type {
  Client,
  ClientOptions,
  Config,
  CreateClientConfig,
  Options,
  OptionsLegacyParser,
  RequestOptions,
  RequestResult,
  TDataShape,
} from './types.js';
export { createConfig } from './utils.js';
export type { Auth, QuerySerializerOptions } from './core/index.js';
export {
  formDataBodySerializer,
  jsonBodySerializer,
  urlSearchParamsBodySerializer,
} from './core/index.js';
